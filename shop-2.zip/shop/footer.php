<?php




?>

<!DOCTYPE html>
<html >
    <head>
        <title></title>
        
    </head>
    <body style="margin:0;">
        <div style="width: 100%-100px;height: 150px;background-color: rgb(255,204,204);display: flex;padding:50px;text-align:center">
            <div style="width:75%;margin-right:auto;margin-left:auto;display:flex">
                <div style=" width:30%;margin-right:auto;margin-left:auto;">
                    <p>STAY CONNECTED</p>
                    <a href=""><Img src="images/face.png"/></a>
                    <a href=""><Img src="images/twitter.png"/></a>
                    <a href=""><Img src="images/instegram.png"/></a>
                </div> 

                <div style=" width:30%;margin-right:auto;margin-left:auto;">
                    <p>BE OUR FRIEND</p>
                    <input style="font-size:20px;padding:5px;background-color:rgb(255,232,232);color:white;border:none;width:89% " type="text" placeholder="Enter your Email here*"/><br>
                    <input style="border:none;font-size:20px;padding:5px;background-color:rgb(9,8,102);color:white;width:92%;margin-top:5px" value="Subscribe Now" type="submit" placholder="Enter your Email here*"/>
                </div> 

                <div style=" width:30%;margin-right:auto;margin-left:auto;">
                    <p>NEED ASSISTANCE?</p>

                    <p>123-456-7890</p>

                    <p>info@mysite.com</p>
                    


                </div> 
            </div>
            
            
                
        </div>
       
        
        
        
    </body>
</html>